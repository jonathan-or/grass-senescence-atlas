import os
import glob
import pandas as pd

# Define the directory containing GMT files
go_dir = "/Users/joo29/Desktop/pp/pot-in-pot/GO_annotations"

# Identify all unique species from available GMT files
gmt_files = glob.glob(os.path.join(go_dir, "output_*.gmt"))
species_list = set(f.split("_")[-1].replace(".gmt", "") for f in gmt_files)

# Process each species
for species in species_list:
    print(f"Processing {species}...")

    # Find GMT files for this species
    species_gmt_files = glob.glob(os.path.join(go_dir, f"output_*_{species}.gmt"))

    # Initialize an empty list to store data
    data = []

    # Process each GMT file for the species
    for file in species_gmt_files:
        with open(file, "r") as f:
            for line in f:
                parts = line.strip().split("\t")
                if len(parts) >= 3:
                    goid, desc, genes = parts[0], parts[1], parts[2:]
                    data.append((goid, desc, genes))

    # Convert to DataFrame
    df = pd.DataFrame(data, columns=["goid", "desc", "genes"])

    # Merge duplicate GO terms while ensuring all genes are preserved
    df = df.groupby(["goid", "desc"], as_index=False).agg({"genes": lambda x: "\t".join(sorted(set(g for sublist in x for g in sublist)))})

    # Define output file
    output_file = os.path.join(go_dir, f"gmt_data_{species}.txt")

    # Save the output
    df.to_csv(output_file, sep="\t", index=False)

    print(f"Generated: {output_file}")

print("Processing complete for all species! 🎉")
